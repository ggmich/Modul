<?php 
	//library yang diperlukan
?>

<?php include "../layout/head.php" ?>





<?php include '../layout/footer.php'; ?>